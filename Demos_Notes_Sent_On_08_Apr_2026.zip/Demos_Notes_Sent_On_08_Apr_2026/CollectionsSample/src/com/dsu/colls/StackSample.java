package com.dsu.colls;

import java.util.Stack;

public class StackSample {
	Stack <String> myStack = new Stack<String>();
	// push pop
	public void populateStack()
	{
		myStack.push("Allahabad");
		myStack.push("Faridabade");
		myStack.push("Ernakulam");
		myStack.push("Coimbatore");
		myStack.push("Faridabad");
		myStack.push("Hyderabad");

	}
	public void fetchStack()
	{
		System.out.println("The Elements in Stack ...");
		while(myStack.isEmpty() == false)
		{
			String city =  myStack.pop();
			System.out.println("City is "+city);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackSample sSample = new StackSample();
		sSample.populateStack();
		sSample.fetchStack();
	}

}
