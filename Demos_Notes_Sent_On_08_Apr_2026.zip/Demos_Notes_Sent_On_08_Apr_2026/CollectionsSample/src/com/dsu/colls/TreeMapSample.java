package com.dsu.colls;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import com.dsu.pojo.Employee;

public class TreeMapSample {

	TreeMap <String,Employee> tMap = new TreeMap<String,Employee>();
	public void populateTreeMap()
	{
		tMap.put("E003", new Employee("E003","Rajendra","Malleswaram","Raj@gmail.com",13000.0f));
		Employee emp1 = new Employee("E001","Harsha","RTNagar","Harsha@gmail.com",12000.0f);		
		tMap.put("E001", emp1);
		tMap.put("E005", new Employee("E005","Sudarshan","Jayanagar","Sudarshan@gmail.com",15000.0f));
		tMap.put("E002", new Employee("E002","Kiran Kumar","Koramangala","Harsha@gmail.com",12000.0f));
		tMap.put("E006", new Employee("E006","Manu","Malleswaram","Manu@gmail.com",16000.0f));
		tMap.put("E004", new Employee("E004","Shyam Kumar","Vijayanagar","SHyam@gmail.com",14000.0f));
		tMap.put("E004", new Employee("E004","Sunder Raj","Koramangala","Sunder@gmail.com",13500.0f));
	}
	public void fetchTreeMapUSingKeySet()
	{
		Set <String> myKeySet = tMap.keySet();
		//tMap.descendingKeySet()
		Iterator <String> keySetIter = myKeySet.iterator();
		while(keySetIter.hasNext())
		{
			String myKey = keySetIter.next();
			System.out.println("The Key is "+myKey+" And corresponding value is "+tMap.get(myKey));
		}
	}
	public void fetchTreeMapUsingDescKeySet()
	{
		Set <String> myDescKeySet = tMap.descendingKeySet();
		Iterator <String> myDescKeyIter = myDescKeySet.iterator();
		while(myDescKeyIter.hasNext())
		{
			String myKey = myDescKeyIter.next();
			System.out.println("The Key is "+myKey+" And corresponding value is "+tMap.get(myKey));
		}
				
	}
	public void fetchTreeMapValues()
	{
	Collection <Employee> myCollection =  tMap.values();
	Iterator <Employee> myColIter = myCollection.iterator();
		while(myColIter.hasNext())
		{
			Employee employee = myColIter.next();
			System.out.println("The Value Present in TreeMap "+employee);
		}
		
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMapSample tms = new TreeMapSample();
		tms.populateTreeMap();
		tms.fetchTreeMapUSingKeySet();
		System.out.println("-----Descending Order of Keys----");
		tms.fetchTreeMapUsingDescKeySet();
		System.out.println("-------Values------");
		tms.fetchTreeMapValues();

	}

}
