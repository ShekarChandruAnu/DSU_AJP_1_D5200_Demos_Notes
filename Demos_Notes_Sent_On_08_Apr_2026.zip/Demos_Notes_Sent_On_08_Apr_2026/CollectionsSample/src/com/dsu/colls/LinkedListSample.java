package com.dsu.colls;

import java.util.Iterator;
import java.util.LinkedList;

import com.dsu.pojo.Employee;

public class LinkedListSample {

	LinkedList <Employee> employeesLL =new LinkedList<Employee>();
	
	public void populateEmployeesLList()
	{
		employeesLL.addFirst(new Employee("E001a","SreeHarsha","RTNagar","sreeharsha@gmail.com",13000.0f));
		Employee e1 = new Employee("E001","Harsha","RTNagar","harsha@gmail.com",12000.0f);
		employeesLL.add(e1);
		employeesLL.add(new Employee("E002","Rajesh","Vijayanagar","rajesh@gmail.com",13000.0f));
		employeesLL.add(new Employee("E003","Kiran","Koramangala","kiran@gmail.com",14000.0f));
		employeesLL.add(new Employee("E004","Keerthana","Indiranagar","keerthan@gmail.com",15000.0f));
		employeesLL.add(new Employee("E005","Mahesh Kumar","RTNagar","mahesh@gmail.com",16000.0f));
		employeesLL.add(new Employee("E006","Sumanth","JCNagar","sumanth@gmail.com",17000.0f));
		employeesLL.addLast(new Employee("E006a","Sumathi","Koramangala","sumathi@gmail.com",14000.0f));
	}
	public void fetchLinkedListUsingIterator()
	{
		//FETCHING 
		Iterator <Employee> empIter = employeesLL.iterator();
		System.out.println("Fetching in Forward Direction....");
		while(empIter.hasNext())
		{
			Employee employee = empIter.next();
			System.out.println(employee);
		}
		//Removing index 4 
		System.out.println("After Removal of Employee at 4...");
		employeesLL.remove(4);
		Iterator <Employee> empIter1 = employeesLL.iterator();
		while(empIter1.hasNext())
		{
			Employee employee = empIter1.next();
			System.out.println(employee);
		}
		
		System.out.println("fetching in Reverse Direction...");
		Iterator <Employee> empDescIter = employeesLL.descendingIterator();
		while(empDescIter.hasNext())
		{
			Employee employee = empDescIter.next();
			System.out.println(employee);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedListSample lls = new LinkedListSample();
		lls.populateEmployeesLList();
		lls.fetchLinkedListUsingIterator();

	}

}
