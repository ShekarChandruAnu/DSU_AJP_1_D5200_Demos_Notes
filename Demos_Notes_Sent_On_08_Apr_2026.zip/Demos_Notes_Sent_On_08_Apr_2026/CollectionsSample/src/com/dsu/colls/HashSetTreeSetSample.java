package com.dsu.colls;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	HashSet <String> hSet = new HashSet<String>();
	TreeSet <String> tSet = new TreeSet<String>();
	public void populateHashSet()
	{
		hSet.add("Faridabad");
		hSet.add("Chandigarh");
		hSet.add("Hyderabad");
		hSet.add("Coimbatore");
		hSet.add("Bangalore");
		hSet.add("Gandhinagar");
		hSet.add("Ernakulam");
		hSet.add("Ernakulam");
		
	}
	public void fetchHashSetData()
	{
		Iterator <String> hSetIter = hSet.iterator();
		System.out.println("Displaying Hash Set Objects....");
		while(hSetIter.hasNext())
		{
			System.out.println(hSetIter.next());
		}
	}
	public void populateTreeSet()
	{
		tSet.add("Faridabad");
		tSet.add("Chandigarh");
		tSet.add("Hyderabad");
		tSet.add("Coimbatore");
		tSet.add("Bangalore");
		tSet.add("Gandhinagar");
		tSet.add("Ernakulam");
		hSet.add("Ernakulam");
	}
	public void fethTreeSetData()
	{
		Iterator <String> tSetIter = tSet.iterator();
		System.out.println("Displaying Tree Set Objects....");
		while(tSetIter.hasNext())
		{
			System.out.println(tSetIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		System.out.println(" -------HashSet Data------");
		hsts.populateHashSet();
		hsts.fetchHashSetData();
		System.out.println(" -------TreeSet Data------");
		hsts.populateTreeSet();
		hsts.fethTreeSetData();
		

	}

}
