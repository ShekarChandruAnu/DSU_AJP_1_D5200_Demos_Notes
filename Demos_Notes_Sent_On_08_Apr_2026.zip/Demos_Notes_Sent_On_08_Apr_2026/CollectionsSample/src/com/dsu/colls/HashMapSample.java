package com.dsu.colls;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.dsu.pojo.Employee;

public class HashMapSample {

	HashMap <String,Employee> hMap = new HashMap<String,Employee>();
	
	public void populateHashMap()
	{
		Employee emp1 = new Employee("E001","Harsha","RTNagar","Harsha@gmail.com",12000.0f);		
		hMap.put("E001", emp1);
		hMap.put("E002", new Employee("E002","Kiran Kumar","Koramangala","Harsha@gmail.com",12000.0f));
		hMap.put("E003", new Employee("E003","Rajendra","Malleswaram","Raj@gmail.com",13000.0f));
		hMap.put("E004", new Employee("E004","Shyam Kumar","Vijayanagar","SHyam@gmail.com",14000.0f));
		hMap.put("E005", new Employee("E005","Sudarshan","Jayanagar","Sudarshan@gmail.com",15000.0f));
		hMap.put("E006", new Employee("E006","Manu","Malleswaram","Manu@gmail.com",16000.0f));
	}
	public void fetchHMapDataUsingKeySet()
	{
		Set <String> myKeySet = hMap.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The Value for the Key "+myKey+" is "+hMap.get(myKey));
		}
	}
	public void fetchMapDataUsingEntrySet()
	{
		Set <Entry <String,Employee>> myEntrySet = hMap.entrySet();
		Iterator <Entry <String,Employee>> myEntryIter =  myEntrySet.iterator();
		while(myEntryIter.hasNext())
		{
			Entry <String,Employee> myEntry = myEntryIter.next();
			System.out.println("The Key is "+myEntry.getKey()+" Corresponding Value is "+myEntry.getValue());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		hms.fetchHMapDataUsingKeySet();
		System.out.println("---------------Using EntrySet-------");
		hms.fetchMapDataUsingEntrySet();

	}

}
