package com.dsu.colls;

import java.util.ArrayList;
import java.util.Iterator;

import com.dsu.pojo.Employee;

public class EmployeeArrayList {
/*
	Customer cust1 = new Customer();
	int num1;
	ArrayList myList = new ArrayList();
	*/
	ArrayList <Employee> employees = new ArrayList<Employee>();
	/*
	LinkedList <Employee> employeesLL = new ArrayList<Employee>();
	HashSet <Employee> empSet = new HashSet<Employee>();
	HashMap <String,Employee> myMap = new HashMap<String,Employee>()
	*/
			
	public void populateArrayList()
	{
		Employee e1 = new Employee("E001","Harsha","RTNagar","harsha@gmail.com",12000.0f);
		employees.add(e1);
		employees.add(new Employee("E002","Rajesh","Vijayanagar","rajesh@gmail.com",13000.0f));
		employees.add(new Employee("E003","Kiran","Koramangala","kiran@gmail.com",14000.0f));
		employees.add(new Employee("E004","Keerthana","Indiranagar","keerthan@gmail.com",15000.0f));
		employees.add(new Employee("E005","Mahesh Kumar","RTNagar","mahesh@gmail.com",16000.0f));
		employees.add(new Employee("E006","Sumanth","JCNagar","sumanth@gmail.com",17000.0f));
		
	}
	public void fetchArrayList()
	{
		//Fetch through For each Loop
		for(Employee employee:employees)
		{
			System.out.println(employee);
		}
		System.out.println("Third Record "+employees.get(2));
		employees.remove(3); // removes bject at index 3 [0,1,2,3]
		System.out.println("after Removal.... at index 3");
		for(Employee employee:employees)
		{
			System.out.println(employee);
		}
		
	}
	public void fetchArrayListUsingIterator()
	{
		//Iterator empIter = employees.iterator();
		Iterator <Employee> empIter = employees.iterator();
		while(empIter.hasNext())
		{	/*
			Employee employee = (Employee)empIter.next();
			*/
			Employee employee = empIter.next();
			System.out.println(employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeArrayList eList = new EmployeeArrayList();
		eList.populateArrayList();
		eList.fetchArrayList();

	}

}
