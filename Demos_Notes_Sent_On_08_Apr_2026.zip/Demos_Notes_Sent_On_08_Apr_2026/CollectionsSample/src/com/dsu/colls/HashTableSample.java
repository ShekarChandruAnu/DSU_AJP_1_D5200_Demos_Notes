package com.dsu.colls;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import com.dsu.pojo.Employee;

public class HashTableSample {

	Hashtable <String,Employee> hTable = new Hashtable<String,Employee>();
	public void populateHashTable()
	{
		Employee emp1 = new Employee("E001","Harsha","RTNagar","Harsha@gmail.com",12000.0f);		
		hTable.put("E001", emp1);
		hTable.put("E002", new Employee("E002","Kiran Kumar","Koramangala","Harsha@gmail.com",12000.0f));
		hTable.put("E003", new Employee("E003","Rajendra","Malleswaram","Raj@gmail.com",13000.0f));
		hTable.put("E004", new Employee("E004","Shyam Kumar","Vijayanagar","SHyam@gmail.com",14000.0f));
		hTable.put("E005", new Employee("E005","Sudarshan","Jayanagar","Sudarshan@gmail.com",15000.0f));
		hTable.put("E006", new Employee("E006","Manu","Malleswaram","Manu@gmail.com",16000.0f));
	}
	
	public void getHashTableDataUsingKeys()
	{
		Enumeration <String> keyEnumer = hTable.keys();
		while(keyEnumer.hasMoreElements())
		{
			String myKey = keyEnumer.nextElement();
			System.out.println("The Value for the Key "+myKey+" is "+hTable.get(myKey));
		}
	}
	public void getHashTableDataUsingKeySet()
	{
		 Set <String> myKeySet= hTable.keySet();
		 Iterator <String> myKeyIter = myKeySet.iterator();
		 while(myKeyIter.hasNext())
		 {
			 String myKey  = myKeyIter.next();
			 System.out.println("The Value for the Key "+myKey+" is "+hTable.get(myKey));
		 }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTableSample hts = new HashTableSample();
		hts.populateHashTable();
		hts.getHashTableDataUsingKeys();
		System.out.println("------------");
		hts.getHashTableDataUsingKeySet();

	}

}
