package com.dsu.colls;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayLisSample {
	
	ArrayList myList = new ArrayList();
	public void populateArrayList()
	{
		myList.add(20000);//Integer
		myList.add("Employee Data");//String
		myList.add(23647.56); //Float
		myList.add(true);// Boolean vs boolean
		myList.add(123.4567748); // Double vs double
		
	}
	public void displayArrayListObjects()
	{
		//METHOD 1
		System.out.println(myList);
		/*
		 * int arr[] = new int[]{100,200,300,400,500};
		 * for(int x:arr)
		 * {
		 * syso(x)
		 * }
		 */
		//METHOD 2
		for(Object obj:myList)
		{
			System.out.println(obj);
		}
		//METHOD 3 using Iterable-Iterator
	Iterator listIter =	myList.iterator();
	while(listIter.hasNext())
	{
		Object obj = listIter.next();
		System.out.println(obj);
	}
		
		
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayLisSample als = new ArrayLisSample();
		als.populateArrayList();
		als.displayArrayListObjects();
	}

}
