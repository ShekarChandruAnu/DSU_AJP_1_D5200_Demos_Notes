package com.dsu.pojo;

public class Employee {
	
	String empId;
	String empName;
	String empAddress;
	String empMail;
	float empSalary;
	
	
	public Employee() {
		super();
	}
	
	
	public Employee(String empId, String empName, String empAddress, String empMail, float empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empMail = empMail;
		this.empSalary = empSalary;
	}


	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public String getEmpMail() {
		return empMail;
	}
	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAddress=" + empAddress + ", empMail="
				+ empMail + ", empSalary=" + empSalary + "]";
	}
	
	/**/
	

}
