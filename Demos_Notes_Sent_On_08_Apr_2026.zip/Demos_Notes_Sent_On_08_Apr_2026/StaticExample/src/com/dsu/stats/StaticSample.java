package com.dsu.stats;

public class StaticSample {
	
	int nonStaticVar;
	static int staticVar;
	
	public static void staticMethod1()
	{
		staticVar++;
		//nonStaticVar++; // NOT ACCESSIBLE since it is non static
		System.out.println("The Static Variable in STATIC METHOD 1   : "+staticVar); //1
	}
	
	public void nonStaticMethod1()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Variable in NON STATIC METHOD 1  : "+staticVar); // 2 //5
		System.out.println("The Non Static Variable in NON STATIC METHOD 1 :"+nonStaticVar); // 1 //1
	}
	
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("The Static Variable in STATIC METHOD 2  : "+staticVar); //4
	}
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Variable in NON STATIC METHOD 2  : "+staticVar); // 3 //6
		System.out.println("The NON Static Variable in NON STATIC METHOD 2 :"+nonStaticVar); // 2 //2
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StaticSample stat1 = new StaticSample();
		
		StaticSample.staticMethod1();
		stat1.nonStaticMethod1();
		stat1.nonStaticMethod2();
		
		StaticSample stat2 = new StaticSample();
		
		StaticSample.staticMethod2();
		stat2.nonStaticMethod1();
		stat2.nonStaticMethod2();
		

	}

}
