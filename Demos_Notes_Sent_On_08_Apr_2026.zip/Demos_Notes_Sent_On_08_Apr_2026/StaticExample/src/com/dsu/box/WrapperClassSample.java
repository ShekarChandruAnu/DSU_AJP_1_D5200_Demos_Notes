package com.dsu.box;

public class WrapperClassSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int score = 80;
		Integer scoreInt = new Integer(score);
		
		String strFloat = "2345.67";
		String strDouble = "5373773.3456";
		String strInteger = "29290";
		String strLong = "22728828";
		
		//UNBOXING -WRAPPER CLASSES HELP TO DO THIS
		float fltStr = Float.parseFloat(strFloat);
		double dblStr = Double.parseDouble(strDouble);
		int intStr = Integer.parseInt(strInteger);
		long lngStr = Long.parseLong(strLong);
		
		System.out.println("The String converted to float "+fltStr);
		System.out.println("The String converted to double "+dblStr);
		System.out.println("The String converted to int  "+intStr);
		System.out.println("The String converted to long  "+lngStr);
		
		// USING WRAPPER CLASSES TO HOLD PRIMITIVE IN THE FORM OBJECTS - Boxing Implicit automatically
		Double dblValue = new Double(dblStr);
		Float fltValue = new Float(fltStr);
		Long lngValue = new Long(lngStr);
		Integer intValue = new Integer(intStr); 
		
		System.out.println("----------WRAPPER CLASSES DISPLAYED ON CONSOLE IMPLICIT toString() method invoked--------");
		System.out.println(" Double Object "+dblValue);
		System.out.println(" Float Object "+fltValue);
		System.out.println(" Integer Object "+intValue);
		System.out.println(" Long Object "+lngValue);
		
		// CONVERT OBJECTS TO STRING WHEN NEEDED EXPLIXIT USAGE OF toString() method
		String dblStr1  = dblValue.toString();
		String fltStr1 = fltValue.toString();
		String intStr1 = intValue.toString();
		String lngStr1 = intValue.toString();
		System.out.println(" String converted from Wrapper Class Objects");
		System.out.println("Float to String "+fltStr1);
		System.out.println("Double to String "+dblStr1);
		System.out.println("Integer to String "+intStr1);
		System.out.println("Long  to String "+lngStr1);
		
		

	}

}
