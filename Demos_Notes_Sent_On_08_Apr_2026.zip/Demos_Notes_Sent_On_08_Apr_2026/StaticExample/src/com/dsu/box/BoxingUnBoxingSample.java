package com.dsu.box;

public class BoxingUnBoxingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int var1 = 100;
		Object object = new Object();
		//BOXING value type to reference type IMPLICIT
		object = var1;
		System.out.println("The value embedded in Object "+object);
		//UNBOXING EXPLICIT CONVERSION OF REF TYPE TO VALUE TYPE 
		int var2 = 200;
		var2 = (int) object;
		System.out.println("The Reference type cast to Value type "+var2);

	}

}
