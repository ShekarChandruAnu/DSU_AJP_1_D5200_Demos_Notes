package com.dsu.finals;
final class MyFinalClass
{
	// final method cannot be OVERRIDDEN
		public final void finalMethod()
		{
			System.out.println("Displaying Final Method Data...");
		}
}
class NonFinalClass // extends FinalClass: extending Final Class Not allowed
{
	// constant variable NUM
	final static int NUM1=100; // final cannot be changed and global 
	final int NUM2 = 200; //final cannot be changed but instance specific
	public void nonFinalMethod()
	{
		System.out.println("Non Final Method data");
		System.out.println("The final data "+NUM1);
		System.out.println("The final static data "+NUM2);
		 // num1+=10; final cannot be changed
	//	num2+=20; final cannot be changed
		
	}
}
class DerivedClass extends NonFinalClass{
	@Override
	public void nonFinalMethod()
	{
		System.out.println("Non Final Method Overridden");
	}
	
}
public class SampleFinalClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFinalClass mfc = new MyFinalClass();
		mfc.finalMethod();
		
		NonFinalClass nfc = new NonFinalClass();
		nfc.nonFinalMethod();
	}

}
