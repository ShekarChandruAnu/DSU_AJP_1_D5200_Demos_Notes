package com.dsu.serial;

import java.io.Serializable;

public class Customer implements Serializable{
	
	String customerId;
	String customerName;
	String customerAddress;
	String customerMail;
	int purchaseValue;
	transient float salesTax;
	// Default Constr Overloaded Constr Getters/Setters/toString()
	public Customer() {
		super();
	}

	public Customer(String customerId, String customerName, String customerAddress, String customerMail,
			int purchaseValue, float salesTax) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerMail = customerMail;
		this.purchaseValue = purchaseValue;
		this.salesTax = salesTax;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerMail() {
		return customerMail;
	}

	public void setCustomerMail(String customerMail) {
		this.customerMail = customerMail;
	}

	public int getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(int purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	public float getSalesTax() {
		return salesTax;
	}

	public void setSalesTax(float salesTax) {
		this.salesTax = salesTax;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerMail=" + customerMail + ", purchaseValue=" + purchaseValue
				+ ", salesTax=" + salesTax + "]";
	}
	
	

}
