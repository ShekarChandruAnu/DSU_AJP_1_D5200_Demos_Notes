package com.dsu.serial;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class DeSerializerClass {

	ObjectInputStream ois;
	ArrayList <Customer> myCustomers;
	public void deSerializeCustomers()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("Customers.txt"));
			myCustomers = (ArrayList<Customer>) ois.readObject();
			System.out.println("The DeSErialized Objects are..");
			for(Customer customer:myCustomers)
			{
				System.out.println(customer);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeSerializerClass dsc = new DeSerializerClass();
		dsc.deSerializeCustomers();

	}

}
