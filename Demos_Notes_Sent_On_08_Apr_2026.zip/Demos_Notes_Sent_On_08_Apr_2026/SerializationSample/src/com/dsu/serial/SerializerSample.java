package com.dsu.serial;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SerializerSample {

	ObjectOutputStream ops;
	public void serializeCustomers()
	{
		/*
		FileOutputStream fops = new FileOutputStream("Customers.txt");
		ops = new ObjectOutputStream(fops);*/
		ArrayList <Customer> customers = new ArrayList<Customer>();
		customers.add(new Customer("C001","Harsha","RTNagar","harsha@gmail.com",12000,123.45f));
		customers.add(new Customer("C002","SreeHarsha","Koramangala","Sreeharsha@gmail.com",13000,223.45f));
		customers.add(new Customer("C003","Kiran Kumar","Malleswaram","kiran@gmail.com",14000,323.45f));
		customers.add(new Customer("C004","Rajesh","Indiranagar","rajesh@gmail.com",15000,423.45f));
		customers.add(new Customer("C005","Rajendra","RTNagar","rajendra@gmail.com",16000,523.45f));
		try {
			ops = new ObjectOutputStream(new FileOutputStream("Customers.txt"));
			ops.writeObject(customers);
			ops.flush();
			ops.close();
			System.out.println("We Serialized Custoemrs Objects successfully...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SerializerSample serialSample = new SerializerSample();
		serialSample.serializeCustomers();

	}

}
