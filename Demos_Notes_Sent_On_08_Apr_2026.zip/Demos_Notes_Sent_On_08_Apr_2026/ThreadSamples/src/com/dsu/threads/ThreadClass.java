package com.dsu.threads;
class MyFinalThread extends Thread
{
	public MyFinalThread()
	{
		start();
	}
	public void run()
	{
		System.out.println(" Child Thread Started ....");
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Thread Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public class ThreadClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In Main Thread");
		System.out.println("Invoking Child Thread....");
		MyFinalThread mft = new MyFinalThread();
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Exiting Main Thread...");
	}

}
