package com.dsu.threads;
class MyThread implements Runnable
{
	Thread t1;
	public MyThread()
	{
		t1 = new Thread(this,"Child Thread");
		System.out.println("Child Thread "+t1);
		t1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("In The Child Thread...");
		System.out.println("Thread Functionality executed...");
		System.out.println("Exiting Child Thread...");
		
	}
	
}
public class ThreadSample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread.....");
		
		MyThread mt = new MyThread();
		System.out.println("DOING FUnctions of  Main Thread...");
		System.out.println("Exiting Main Thread...");

	}

}
