package com.dsu.threads;
class MyThreadAgain implements Runnable
{
	Thread t1;
	public MyThreadAgain()
	{
		t1 = new Thread(this,"Child Thread");
		t1.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Thread Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class JoinSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread..");
		System.out.println("Invoking Child Thread...");
		MyThreadAgain mta = new MyThreadAgain();
		System.out.println("Is Child Thread ALive "+mta.t1.isAlive());
		try {
			mta.t1.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Is Child Thread Still ALive "+mta.t1.isAlive());
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Exiting Main Thread...");

	}

}
