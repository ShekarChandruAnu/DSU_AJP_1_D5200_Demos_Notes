package com.dsu.threads;

public class MainThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread currentThread = Thread.currentThread();
		System.out.println("Current Thread "+currentThread);
		currentThread.setName("New Thread...");
		System.out.println("Thread after Name Change "+currentThread);
		// 1 to 10
		// MAX_PRIORITY 10
		// MIN_PRIORITY 1
		// NORM_PRIORITY 5
	}

}
