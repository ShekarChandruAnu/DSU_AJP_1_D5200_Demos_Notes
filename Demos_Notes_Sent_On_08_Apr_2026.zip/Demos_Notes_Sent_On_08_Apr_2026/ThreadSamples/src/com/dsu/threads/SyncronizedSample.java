package com.dsu.threads;
class MyClass
{
	public /*synchronized*/ void  processOrder()
	{
		System.out.println(" Produced Goods");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Consumed  Goods...");
	}
}
class MyThread1 implements Runnable
{
	MyClass mc;
	Thread t1;
	public MyThread1(MyClass mc)
	{
		t1 = new Thread(this,"ChildThread");
		this.mc = mc;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized(mc)
		{
			mc.processOrder();
		}
	}
	
}

public class SyncronizedSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In The Main Thread...");
		System.out.println("Exiting Main THread...");
		MyClass mc1 = new MyClass();
		MyThread1 mt1 = new MyThread1(mc1);
		MyThread1 mt2 = new MyThread1(mc1);
		MyThread1 mt3 = new MyThread1(mc1);
		MyThread1 mt4 = new MyThread1(mc1);
		mt1.t1.start();
		mt2.t1.start();
		mt3.t1.start();
		mt4.t1.start();
		

	}

}
