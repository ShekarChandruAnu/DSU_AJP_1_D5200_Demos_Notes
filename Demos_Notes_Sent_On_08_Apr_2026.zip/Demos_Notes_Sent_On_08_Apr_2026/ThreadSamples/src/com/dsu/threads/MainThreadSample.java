package com.dsu.threads;
class MyNewThread implements Runnable
{
	Thread t1;
	public MyNewThread()
	{
		t1 = new Thread(this,"Child Thread");
		t1.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("In Child Thread");
		for(int i=0;i<5;i++)
		{
			try {
				System.out.println("Child Thread Loop "+(i+1));
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class MainThreadSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread ....");
		System.out.println("About to Invoke Child Thread...");
		MyNewThread mnt = new MyNewThread();
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Back In the Main Thread Exiting Main Thread");

	}

}
