package com.dsu.files;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {
	
	FileWriter fWriter;
	String str = "We are writing to Char Stream";
	public void writeToFile()
	{
		
			try {
				//
				fWriter = new FileWriter("customer.txt");
				fWriter.write(str);
				fWriter.flush();
				fWriter.close();
				System.out.println("Written Character Data into Char STream...");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FileWriterSample fws = new FileWriterSample();
		fws.writeToFile();

	}

}
