package com.dsu.files;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamSample {

	FileOutputStream fos;
	byte myBytes[] = new byte[200];
	String strBytes = "We are writing to Binary Stream...";
	public void writeToBinaryStream()
	{
		try {
			fos = new FileOutputStream("employee.txt");
			myBytes = strBytes.getBytes();
			fos.write(myBytes);
			fos.flush();
			fos.close();
			System.out.println("We wrote to Binary STream successfully...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FileOutputStreamSample  foss = new FileOutputStreamSample();
		foss.writeToBinaryStream();
	}

}
