package com.dsu.files;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamSample {
	FileInputStream fis;
	
	byte myBytes[] = new byte[200];
	public void readFromBinaryStream()
	{
		try {
			fis = new FileInputStream("employee.txt");//Read from Binary STream and put into Byte array
			fis.read(myBytes);
			//Converting Bytes into STring using String Constructor
			String readStr = new String(myBytes);
			System.out.println("Data Read is "+readStr);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStreamSample fiss = new FileInputStreamSample();
		fiss.readFromBinaryStream();

	}

}
