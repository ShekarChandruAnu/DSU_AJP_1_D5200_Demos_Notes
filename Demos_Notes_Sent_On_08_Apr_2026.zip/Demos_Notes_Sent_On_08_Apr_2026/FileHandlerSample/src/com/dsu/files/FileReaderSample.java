package com.dsu.files;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderSample {

	FileReader fReader;
	int iChar;
	public void readFromFile()
	{
		try {
			fReader = new FileReader("customer.txt");
			while((iChar = fReader.read()) != -1)
			{
				System.out.print((char)iChar);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReaderSample frs = new FileReaderSample();
		frs.readFromFile();

	}

}
