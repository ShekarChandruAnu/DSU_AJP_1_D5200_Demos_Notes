package com.dsu.files;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedInputStreamSample {

	BufferedInputStream bis;
	byte[] myBytes = new byte[200];
	public void readFromBinaryThruStream()
	{
		try {
			bis = new BufferedInputStream(new FileInputStream("supplier.txt"));
			bis.read(myBytes);
			String strBytes = new String(myBytes);
			System.out.println("The Data Read from Binary using Buffer..."+strBytes);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamSample biss = new BufferedInputStreamSample();
		biss.readFromBinaryThruStream();

	}

}
