package com.dsu.files;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BuffereOutputStreamSample {
	
	BufferedOutputStream bos;
	String str = "We are writing data to Binary STream through Buffer";
	byte myBytes[] = new byte[200];
	public void writeToBinaryThruBuffer()
	{
		try {
		/*	FileOutputStream fos = new FileOutputStream("supplier.txt");
			bos = new BufferedOutputStream(fos);*/
		//	bos = new BufferedOutputStream(new FileOutputStream("supplier.txt"),100000);
			bos = new BufferedOutputStream(new FileOutputStream("supplier.txt"));
			myBytes = str.getBytes();		
			bos.write(myBytes);
			bos.flush();
			bos.close();
			System.out.println("We wrote Data to Binary STream thru Buffer..");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BuffereOutputStreamSample bops = new BuffereOutputStreamSample();
		bops.writeToBinaryThruBuffer();

	}

}
