package com.anu.dsu;

public class Employee {
	String empId;
	String empName;
	String empAddress;
	float empSalary;
	
	public void initializeData()
	{
		empId = "E001";
		empName = "Harsha";
		empAddress = "RTNagar";
		empSalary = 10000.0f;
	}
	public void displayEmployeeDetails()
	{
		System.out.println(" Employee Details are");
		System.out.println("Employee ID  "+empId);
		System.out.println("Employee Name "+empName);
		System.out.println("Employee Address "+empAddress);
		System.out.println("Employee Salary "+empSalary);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee1 = new Employee();
		employee1.initializeData();
		employee1.displayEmployeeDetails();

	}

}
