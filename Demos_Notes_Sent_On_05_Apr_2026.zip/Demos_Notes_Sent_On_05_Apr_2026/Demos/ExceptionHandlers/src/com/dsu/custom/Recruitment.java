package com.dsu.custom;

public class Recruitment {
	public void callCheckAge(int age)
	{
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
		}
	}
	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("Age Scrutiny Underway....");
		if( age < 20 || age > 30)
		{
		//	InvalidAgeException iae = new InvalidAgeException("Age to be in the Range 20-30");
			//throw iae
			System.out.println("Age is "+age);
			throw new InvalidAgeException("Age to be in the Range 20-30");
		}
		System.out.println("Age is "+age);
		System.out.println("Age Scrutiny Completed...");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Recruitment rc = new Recruitment();
		System.out.println("Recruitment Process Started....");
		/*try
		{*/
			rc.callCheckAge(26);
			rc.callCheckAge(27);
			rc.callCheckAge(18);
			rc.callCheckAge(23);
			rc.callCheckAge(24);
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
		}*/
		
		System.out.println("Recruitment Process Completed...");

	}

}
