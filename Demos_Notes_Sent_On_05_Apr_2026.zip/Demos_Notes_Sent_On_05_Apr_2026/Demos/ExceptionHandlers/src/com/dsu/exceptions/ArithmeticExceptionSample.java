package com.dsu.exceptions;

public class ArithmeticExceptionSample {

	public void calculateDividend(int num1,int num2)
	{
		int result=0;
		System.out.println("We are about to calculate Dividend");
		try
		{
		result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
			
		}
		System.out.println("Result is "+result);
		System.out.println("we finished calculating Dividend");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArithmeticExceptionSample aes = new ArithmeticExceptionSample();
		System.out.println("About to call Dividend");
	/*	try
		{*/
		aes.calculateDividend(100, 50);
		aes.calculateDividend(100, 20);
		aes.calculateDividend(100, 0);
		aes.calculateDividend(100, 25);
		aes.calculateDividend(100, 10);
	/*	}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
			
		}*/
		System.out.println("Finished Calling Dividend");

	}

}
