package com.dsu.exceptions;

public class ArrayIndexExceptionSample {
	
	public void manipulateArray()
	{
		int arr[] = new int[10];
		System.out.println("We are in Array Manipulation..");
		for(int i=0;i<=10;i++)
		{
			arr[i] = (i+1)*10;
			System.out.println(arr[i]);
		}
		System.out.println("Exiting Array Manipulation ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayIndexExceptionSample aies = new ArrayIndexExceptionSample();
		System.out.println("we are about to call array manip...");
		try
		{
			aies.manipulateArray();
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			ae.printStackTrace();
			//System.out.println(ae.getMessage());
		}
		System.out.println("We completed calling array Manip");

	}

}
