package com.dsu.objectarray;

public class Point {
	int xCoord;
	int yCoord;
	
	public Point() {
		super();
	}

	public Point(int xCoord, int yCoord) {
		super();
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}
	
	public void displayCoordinates()
	{
		System.out.println("X Coordinate is "+xCoord+" Y Coordinate is "+yCoord);
	}
	

}
