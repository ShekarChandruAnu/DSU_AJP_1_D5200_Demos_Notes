package com.dsu.objectarray;

public class PointManipulator {
	// public arr1[] return1DArray()
	// public arr2[][] return2DArray()
	
	public Point[] generatePointsArray()
	{
		Point points[] = new Point[10];
		/*
		 * points[0] = new Point();
		 * points[1] = new Point();
		 * ---
		 * points[9] = new Point();
		 */
		for(int i=0;i<points.length;i++)
		{
			points[i] = new Point(i+10,i+11); // Point(10,11)  Point(11,12)
		}
		return points;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PointManipulator pointM = new PointManipulator();
		Point[] myPoints = pointM.generatePointsArray();
	/*	myPoints[0].displayCoordinates();
	 * 
	 * myPoints[9].displayCoordinates();
	 */
		for(int i=0;i<10;i++)
		{
			myPoints[i].displayCoordinates();
		}
		

	}

}
