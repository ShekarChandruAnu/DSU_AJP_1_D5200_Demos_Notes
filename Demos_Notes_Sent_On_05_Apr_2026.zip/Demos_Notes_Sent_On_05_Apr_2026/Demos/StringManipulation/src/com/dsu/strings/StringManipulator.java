package com.dsu.strings;

import java.util.StringTokenizer;

public class StringManipulator {

	public static void main(String[] args)
	{
		String str1 = "Bangalore";
		String str2 = "Bangalore";
		
		System.out.println("str1.equals(str2)  :"+str1.equals(str2));//true or false-true
		System.out.println("str1 == str2 :"+(str1 == str2)); //true or false - true
		
		String str3 = new String("Mangalore");
		String str4 = new String("Mangalore");
		System.out.println("str3.equals(str4)  :"+str3.equals(str4));//true or false
		System.out.println("str3 == str4 :"+(str3 == str4)); //true or false
		
		System.out.println( " str1.charAt(4)  "+str1.charAt(4));//character at index 4
		System.out.println(" str1.indexOf('l') "+str1.indexOf('l'));// index of l
		
		System.out.println(" str1.length() "+str1.length());
		System.out.println(" str1.codePointAt(0) B"+str1.codePointAt(0));
		System.out.println(" str2.codePointAt(0) b"+str2.codePointAt(0));
		
		
		System.out.println(" str1.compareTo(str2) "+str1.compareTo(str2));
		
		System.out.println("---------STRINGBUFFER IS MUTABLE - APPENDED------");
		StringBuffer sbfr1 = new StringBuffer("Bangalore is garden city");
		System.out.println(" initial"+sbfr1);
		sbfr1.append(" And Peaceful");
		System.out.println(" after appending"+sbfr1);
		System.out.println("---------STRINGBUILDER IS MUTABLE - APPENDED------");
		StringBuilder sbldr1 = new StringBuilder("Bangalore is Garden City");
		System.out.println(" initial"+sbldr1);
		sbldr1.append(" And Peaceful");
		System.out.println(" after appending"+sbldr1);
		char[] myarray = new char[] {'C','I','T','Y'};
		sbldr1.insert(9,myarray );
		System.out.println("sbldr1 after insertion "+sbldr1);
		// ctrl + shift + O
		StringTokenizer strToken = new StringTokenizer("India:Is:a:Peaceful:Country",":");
		System.out.println("----STRING TOKENIZER USING NEXT ELEMENT----");
		while(strToken.hasMoreElements())
		{
			System.out.println(strToken.nextElement());
		}
		StringTokenizer strToken1 = new StringTokenizer("India:Is:a:Peaceful:Country",":");
		System.out.println("----STRING TOKENIZER USING NEXT TOKEN----");
		while(strToken1.hasMoreTokens())
		{
			System.out.println(strToken1.nextToken());
		}
		
		
		
		
		
	}
	
}
