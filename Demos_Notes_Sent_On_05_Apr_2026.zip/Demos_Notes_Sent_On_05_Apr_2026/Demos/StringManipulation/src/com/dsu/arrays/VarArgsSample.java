package com.dsu.arrays;

public class VarArgsSample {

	public void calculateAvg(int score1,int score2,String... args)
	{
		float averageScore = (score1+score2)/2;
		System.out.println("The Average for the Countries ");
		for(String country:args)
		{
		System.out.println(country);
		}
		System.out.println(averageScore);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VarArgsSample vars = new VarArgsSample();
		vars.calculateAvg(1000, 2000, "India","Australia","Bangladesh","SriLanka");
		System.out.println("-----------");
		vars.calculateAvg(4500, 3500, "India","Australia","Bangladesh","SriLanka","Bhutan","Nepal");
		System.out.println("-----------");
		vars.calculateAvg(100, 200, "India","Australia");

	}

}
