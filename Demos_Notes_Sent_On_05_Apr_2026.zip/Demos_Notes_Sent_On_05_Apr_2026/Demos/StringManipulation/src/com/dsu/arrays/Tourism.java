package com.dsu.arrays;
public class Tourism
{

	public static void main(String[] args)
	{
	for(int i=0;i<args.length;i++)
	{
		System.out.println("The Country is "+args[i]);
	}

	}

}
