package com.dsu.arrays;

public class JaggedArray {
	
	public void manipulateJaggedArray()
	{
		int jagArray[][] = new int[3][];
		
		jagArray[0] = new int[5];
		jagArray[1] = new int[4];
		jagArray[2] = new int[6];
		
		for(int i=0;i<=4;i++)
		{
			jagArray[0][i] = (i+1)*10;
			System.out.print(jagArray[0][i]+" ");
		}
		System.out.println();
		for(int j=0;j<=3;j++)
		{
			jagArray[1][j] = (j+1)*100;
			System.out.print(jagArray[1][j]+" ");
		}
		System.out.println();
		for(int k=0;k<6;k++)
		{
			jagArray[2][k] = (k+1)*1000;
			System.out.print(jagArray[2][k]+" ");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JaggedArray jar = new JaggedArray();
		jar.manipulateJaggedArray();

	}

}
