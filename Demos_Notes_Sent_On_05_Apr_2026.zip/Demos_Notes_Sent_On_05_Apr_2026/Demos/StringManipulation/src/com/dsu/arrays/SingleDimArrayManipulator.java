package com.dsu.arrays;

public class SingleDimArrayManipulator {

	public void manipulate1DArray()
	{
		int arr1[] = new int[10];
	//	for(int i=0;i<10;i++)
		for(int i=0;i<arr1.length;i++)
		{
			arr1[i]=i+10;
			System.out.println("Element is "+arr1[i]);
		}
	} // take 2 arrays as arghs and add
	public void manipulate2DArray()
	{
		int arr2[][] = new int[3][4];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				arr2[i][j]= (i+j)*10;
				System.out.print(arr2[i][j]+" ");
			}
			System.out.println();
		}
	}
	public int[][] addArrays(int arr1[][],int arr2[][])
	{
		int resultArr[][] = new int[2][2];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				resultArr[i][j] = arr1[i][j]+arr2[i][j];
			}
		}
		return resultArr;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingleDimArrayManipulator sdm = new SingleDimArrayManipulator();
		sdm.manipulate1DArray();
		System.out.println("-------");
		sdm.manipulate2DArray();
		int array1[][] = {{100,200},{300,400}};
		int array2[][] = {{1000,2000},{3000,4000}};
		int arrResult[][] = new int[2][3];
		arrResult = sdm.addArrays(array1, array2);
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(arrResult[i][j]);
			}
			System.out.println();
		}

	}

}
