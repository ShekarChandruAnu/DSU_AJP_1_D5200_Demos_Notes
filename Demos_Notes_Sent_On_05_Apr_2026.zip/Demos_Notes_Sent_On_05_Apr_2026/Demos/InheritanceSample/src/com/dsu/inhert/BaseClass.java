package com.dsu.inhert;

public class BaseClass {
	public void display()
	{
		System.out.println("BaseClass Displayed...");
	}

}
