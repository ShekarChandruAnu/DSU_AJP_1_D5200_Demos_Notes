package com.dsu.inhert;

import java.util.Scanner;

public class Furniture {
	
	
		int length;
		int width;
		int height;
		Scanner scan1 = new Scanner(System.in);
		
		public Furniture() {
			super();
		}

		public Furniture(int length, int width, int height) {
			super();
			this.length = length;
			this.width = width;
			this.height = height;
		}
		public void acceptFurnitureDetails()
		{
			System.out.println("Enter the Length ");
			length = scan1.nextInt();
			System.out.println("Enter the Height ");
			height = scan1.nextInt();
			System.out.println("Enter the Width ");
			width = scan1.nextInt();
		}
		public void displayFurnitureDetails()
		{
			System.out.println("The Furniture Details are");
			System.out.println("The Length is "+length);
			System.out.println("The Width is "+width);
			System.out.println("The Height is "+height);
			
		}
		
		

}
