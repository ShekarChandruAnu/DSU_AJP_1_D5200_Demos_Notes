package com.dsu.inhert;
class Base1
{
	public void display()
	{
		System.out.println("Displaying Base Class");
	}
}
public class Derived1 extends Base1{

	public void display()
	{
		System.out.println("Displaying Derived Class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Base1 base = new Base1();//OK
		Base1 base1 = new Derived1(); // OK
		Derived1 dc = new Derived1() ;//OK
		Derived1 dc1 = (Derived1)new Base1();//NOT OK	
		dc1.display();

	}

}
