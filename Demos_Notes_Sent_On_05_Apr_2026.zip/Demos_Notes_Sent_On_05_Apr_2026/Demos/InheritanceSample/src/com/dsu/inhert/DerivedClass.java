package com.dsu.inhert;

public class DerivedClass extends BaseClass{

	@Override
	public void display()
	{
		System.out.println("Displaying Derived Class..");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	BaseClass bc = new BaseClass();
		bc.display1();
		
		
		dc.display1();
		dc.display2();*/
		DerivedClass dc = new DerivedClass();
		dc.display();

	}

}
