package com.dsu.inhert;

public class BookShelf extends Furniture{

	int noOfShelves;
	
	public void acceptBookShelfDetails()
	{
		/*System.out.println("Enter Length ");
		length = scan1.nextInt();
		
		
		System.out.println("Enter Width ");
		width= scan1.nextInt();
		
		System.out.println("Enter Height ");
		height = scan1.nextInt();*/
	/*	Furniture furn = new Furniture();
		furn.acceptFurnitureDetails();*/
				
		super.acceptFurnitureDetails();
		
		System.out.println("Enter The No Of Shelves");
		noOfShelves = scan1.nextInt();
	}
	public void displayBookShelfDetails()
	{
	/*	System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);*/
		super.displayFurnitureDetails();
		System.out.println("The No of Shelves "+noOfShelves);
	}
	
}
