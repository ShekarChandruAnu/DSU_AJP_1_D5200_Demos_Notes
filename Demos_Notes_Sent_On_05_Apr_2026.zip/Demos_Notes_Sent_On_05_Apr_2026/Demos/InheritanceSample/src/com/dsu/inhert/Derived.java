package com.dsu.inhert;
class Base
{
	public void display()
	{
		System.out.println("Displaying Base Class");
	}
}
public class Derived extends Base{
	public void display()
	{
		System.out.println("Displaying Derived Class");
	}
	public static void main(String args)
	{
		Base base = new Base();//OK
		Base base1 = new Derived(); // OK
		Derived dc = new Derived() ;//OK
		Derived dc1 = (Derived)new Base();//NOT OK	
		dc1.display();
		
	}

}
