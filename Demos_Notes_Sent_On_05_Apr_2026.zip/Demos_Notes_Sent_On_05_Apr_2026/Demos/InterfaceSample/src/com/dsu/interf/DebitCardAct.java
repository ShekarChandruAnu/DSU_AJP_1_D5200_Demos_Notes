package com.dsu.interf;

public interface DebitCardAct extends Account,Taxation{

	public void withdraw();
	public void deposit();
	public void fetchBalance();
}
