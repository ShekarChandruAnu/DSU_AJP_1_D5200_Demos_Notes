package com.dsu.interf;

public interface Account {
	public void createAccount();
	public void closeAccount();
}
