package com.dsu.interf;

public class MyAccount implements CreditCardAct,DebitCardAct,Insurance{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount mac = new MyAccount();
		//ACT RELATED
		mac.createAccount();
		//INSURANCE RELATED
		mac.createPolicy();
		mac.calculatePremium();
		mac.terminatePolicy();
		
		//CREDIT CARD RELATED
		mac.calculateRedemptionPoints();
		mac.checkOutstanding();
		//DEBIT CARD RELATED
		mac.deposit();
		mac.withdraw();
		mac.fetchBalance();
		
		mac.calculateTaxes();
		mac.closeAccount();

	}
/*
 * ALL THESE METHODS HAVE TO BE 
 * CONNECTED WITH OTHER MODULES TO COMPLET THE OPERATIONS
 * IN SOME CASES WITH DB CONNECTIONS
 * HERE WE ARE USING AS DUMMIES JUST FOR INTERFACE UNDERSTANDING
 */
	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account is Created DebitCard & Credit Card");
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Closed");
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("Premium Calculated");
	}

	@Override
	public void createPolicy() {
		// TODO Auto-generated method stub
		System.out.println("Policy Created");
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("Terminated Policy");
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("AMount Withdrawn...");
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("AMount Deposited....");
	}

	@Override
	public void fetchBalance() {
		// TODO Auto-generated method stub
		System.out.println("Fecthed Balance is ");
		
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("Your Rdemption Points are...");
	}

	@Override
	public void checkOutstanding() {
		// TODO Auto-generated method stub
		System.out.println("Your Outstanding is ");
	}
	@Override
	public void calculateTaxes() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Taxes");
	}

}
