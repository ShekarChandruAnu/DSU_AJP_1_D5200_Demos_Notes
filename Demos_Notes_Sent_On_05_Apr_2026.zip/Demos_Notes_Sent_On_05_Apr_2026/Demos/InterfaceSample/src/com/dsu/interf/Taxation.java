package com.dsu.interf;

public interface Taxation {

	public void calculateTaxes();
}
