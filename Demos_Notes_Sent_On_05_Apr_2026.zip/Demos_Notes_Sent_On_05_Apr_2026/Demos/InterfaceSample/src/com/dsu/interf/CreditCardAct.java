package com.dsu.interf;

public interface CreditCardAct extends Account{

	public void calculateRedemptionPoints();
	public void checkOutstanding();
}
