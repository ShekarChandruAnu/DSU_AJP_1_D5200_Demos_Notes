package com.dsu.interf;

public interface Insurance {
	public void calculatePremium();
	public void createPolicy();
	public void  terminatePolicy();

}
