package com.anu.dsu;

public class Customer {

	String customerId;
	String customerName;
	String customerAddress;
	String customerMail;
	float purchaseValue;
	int arr1[] = new int[3];
	
	public Customer()
	{
		customerId = "C001";
		customerName = "Harsha";
		customerAddress = "RTNagar";
		customerMail = "harsha@gmail.com";
		purchaseValue = 12000.0f;
	}/**/
	
public Customer(String customerId,String customerName,String customerAddress,String customerMail,float purchaseValue)
	{
		//Customer c = new Customer();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerMail = customerMail;
		this.purchaseValue = purchaseValue;
		
	}/*	*/
public Customer(String customerId,String customerName,String customerAddress,String customerMail)
{
	//Customer c = new Customer();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerAddress = customerAddress;
	this.customerMail = customerMail;
	
	
}
public Customer(String customerId,String customerName,String customerAddress)
{
	//Customer c = new Customer();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerAddress = customerAddress;
	this.customerMail = customerMail;
}
	public void displayCustomer()
	{
		System.out.println("------The Customer Details are..------");
		System.out.println("Customer Id "+customerId);
		System.out.println("Customer Name "+customerName);
		System.out.println("Customer Address "+customerAddress);
		System.out.println("Customer Mail "+customerMail);
		System.out.println("Purchase Value "+purchaseValue);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer1 = new Customer();
		customer1.displayCustomer();
	Customer customer2 = new Customer("C002","Kiran Kumar","Viajayanagar","kiran@gmail.com",12500.f);
		customer2.displayCustomer();	/**/
		Customer customer3 = new Customer("C003","Santhosh Kumar","Jayanagar","santa@gmail.com");
		customer3.displayCustomer();
		
		Customer customer4 = new Customer("C003","Santhosh Kumar","Jayanagar");
		customer4.displayCustomer();
	}

}
