package com.anu.dsu;

import java.util.StringTokenizer;

public class Student {

	String studId;
	String studName;
	int score;
	
	public Student()
	{
		studId = "";
		studName="";
		score =0;
	}
	public Student(String studId,String studName,int score)
	{
		this.studId = studId;
		this.studName = studName;
		this.score = score;
	}
	public String getStudId()
	{
		return this.studId;
	}
	public void setStudId(String studId)
	{
		this.studId = studId;
	}
	public String getStudName()
	{
		return this.studName;
	}
	public void setStudName(String studName)
	{
		this.studName = studName;
	}
	public int getScore()
	{
		return this.score;
	}
	public void setScore(int score)
	{
		this.score = score;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student();
		student1.setStudId("S001");
		student1.setStudName("Kiran");
		student1.setScore(85);
		
		System.out.println("Student Details are..");
		System.out.println("Student Id "+student1.getStudId());
		System.out.println("Student Name "+student1.getStudName());
		System.out.println("Student Score "+student1.getScore());
		//StringTokenizer strTok = new StringTokenizer("hello:world",":");
		int arr[][] = new int[3][];
		
	}

}
