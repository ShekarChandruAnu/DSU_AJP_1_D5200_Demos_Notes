package com.dsu.poly;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parser parser;// = new Parser();
		parser = new JsonParser();
		parser.parse("JSON File");
		parser.processData();
		
		parser = new PdfParser();
		parser.parse("PDF File");
		
		parser = new XmlParser();
		parser.parse("Xml File");
		
		
		

	}

}
