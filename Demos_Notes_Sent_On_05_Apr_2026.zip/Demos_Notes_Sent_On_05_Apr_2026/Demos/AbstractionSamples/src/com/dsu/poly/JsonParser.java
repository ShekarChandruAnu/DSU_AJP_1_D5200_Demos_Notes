package com.dsu.poly;

public class JsonParser extends Parser{

	@Override
	public void parse(String fileType) {
		// TODO Auto-generated method stub
		System.out.println("The File Type "+fileType+" Is Parsed");
	}

}
