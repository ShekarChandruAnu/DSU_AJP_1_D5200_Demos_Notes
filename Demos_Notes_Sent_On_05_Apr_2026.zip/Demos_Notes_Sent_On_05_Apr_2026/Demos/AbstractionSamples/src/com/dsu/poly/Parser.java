package com.dsu.poly;

public abstract class Parser {
	public abstract void parse(String fileType);
	public void processData()
	{
		System.out.println("Processed Data...");
	}
}
