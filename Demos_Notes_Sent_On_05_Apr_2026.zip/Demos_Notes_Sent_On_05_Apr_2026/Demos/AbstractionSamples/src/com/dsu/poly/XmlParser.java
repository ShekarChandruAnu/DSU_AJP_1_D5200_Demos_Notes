package com.dsu.poly;

public class XmlParser extends Parser{

	@Override
	public void parse(String fileType) {
		// TODO Auto-generated method stub
		System.out.println("The file Type "+fileType+" Is PARSED");
		
	}

	

}
