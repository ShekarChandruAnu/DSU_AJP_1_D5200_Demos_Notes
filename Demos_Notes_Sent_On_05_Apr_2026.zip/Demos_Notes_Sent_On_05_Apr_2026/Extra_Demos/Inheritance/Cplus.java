class Book
{
int price;
int pages;
public void get(int mprice,int mpages)
{
price=mprice;
pages=mpages;
}
public void show()
{
System.out.println(" ");
System.out.println("\t Books Information");
System.out.println("\t Book Price :"+price);
System.out.println("\t Number Of Pages :"+pages);
System.out.println(" ");
}
}
class SoftwareBook extends Book
{
String softwarename;
String softwareversion;
public void getDetails(String msoftwarename,String msoftwareversion)
{
softwarename=msoftwarename;
softwareversion=msoftwareversion;
}
public void showDetails()
{
System.out.println(" ");
System.out.println("\t Software Books Information ");
System.out.println("\t Software Name :"+softwarename);
System.out.println(" \t Software Version:"+softwareversion);
System.out.println(" ");
}
}
class Cplus extends SoftwareBook
{
String author;
String title;
public void getData(String mauthor,String mtitle)
{
author=mauthor;
title=mtitle;
}
public void showData()
{
show();
showDetails();
System.out.println(" ");
System.out.println("\t C++ Books Information ");
System.out.println("\t Author Name :"+author);
System.out.println(" \t Book Title:"+title);
System.out.println(" ");
}
public static void main(String args[])
{
Cplus c=new Cplus();
c.get(45,450);
c.getDetails("Borland C++","5.0");
c.getData("Lee Mitchell","Programming using C++");
c.showData();
}
}

