class Book
{
int price=50;
int pages=500;
public void show()
{
System.out.println(" ");
System.out.println("\t Books Information");
System.out.println("\t Book Price :"+price);
System.out.println("\t Number Of Pages :"+pages);
System.out.println(" ");
}
}
public class SoftwareBook extends Book
{
String softwarename="Borland C++";
String softwareversion="5.0";
public void show()
{
System.out.println(" ");
System.out.println("\t Software Books Information ");
System.out.println("\t Software Name :"+softwarename);
System.out.println(" \t Software Version:"+softwareversion);
System.out.println(" ");
}
public static void main(String args[])
{
SoftwareBook s=new SoftwareBook();
Book b=new Book();
s.show();
b.show();
}
}