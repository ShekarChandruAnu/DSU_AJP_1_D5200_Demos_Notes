interface ItemCount
{
public void noOfItems();
}
class SoftwareProducts implements ItemCount
{
	int os=60;
	int oracle=20;
	int jav=15;
	int tot;
		public void calculate()
		{
			tot=os+oracle+jav;
		}
		public void noOfItems()
		{
			System.out.println();
			System.out.println("   "+"Total number of software products purchased is :"+tot);
		}
}
class HardwareProducts implements ItemCount
{
int printer=20;
int speaker=12;
int harddisk=25;
int htot;
public void calculate1()
{
htot=printer+speaker+harddisk;
}
public void noOfItems()
{
System.out.println();
System.out.println("  "+"Total number of hardware items purchased is :"+htot);
}
}
class Products1
{
public static void main(String args[])
{
SoftwareProducts s=new SoftwareProducts();
HardwareProducts h=new HardwareProducts();
s.calculate();
h.calculate1();
s.noOfItems();
h.noOfItems();
}
}