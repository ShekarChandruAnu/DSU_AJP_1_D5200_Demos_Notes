interface Itemcount
{
public void noOfItems();
}
class SoftwareProducts implements Itemcount
{
int os=60;
int oracle=20;
int jav=15;
int tot;
	public void calculate()
	{
	tot=os+oracle+jav;
	}

public void noOfItems()
{
System.out.println();
System.out.println("  "+"Total Number of Software products purchased is  :"+tot);
}
}
class HardwareProducts implements Itemcount
{
int printer=20;
int speaker=12;
int harddisk=25;
int htot;
public void calculate()
{
htot=printer+speaker+harddisk;
}
public void noOfItems()
{
System.out.println();
System.out.println(" "+"Total number of hardware items purchased is :"+htot);
}
}
class Products
{
public static void main(String args[])
{
SoftwareProducts s=new SoftwareProducts();
HardwareProducts h=new HardwareProducts();
s.calculate();
h.calculate();
s.noOfItems();
h.noOfItems();
}
}





