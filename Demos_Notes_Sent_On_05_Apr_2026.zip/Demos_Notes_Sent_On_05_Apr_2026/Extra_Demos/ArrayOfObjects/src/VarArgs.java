
public class VarArgs {
	
	// three dots represent ellipses
	//ellipses represent variable number of argument
	public void getData(int a,int b,int c,String... args)
	{
		int myResult = a +b+c;
		System.out.println("The Result is "+myResult);
		for(int i=0;i<args.length;i++)
		{
			System.out.println("The String is "+args[i]);
		}
	}
	public void getSData(String s1,String s2)
	{
		System.out.println(" String 1 "+s1+"  String 2 "+s2);
	}
	public void getIdata(int num1,int num2)
	{
		int result = num1+num2;
		System.out.println(" The result is "+result);
	}
//VAR ARGS
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VarArgs va = new VarArgs();
		va.getSData("hello", "World");
		va.getIdata(100, 200);
		// va.getIdata(100,200,300,400)
		va.getData(100, 200, 300, "One","Two","Three");
		va.getData(1000, 2000, 3000, "One","Two","Three","Four");
		va.getData(10, 20, 30, "One","Two","Three","Four","Five");
		va.getData(50,60,70, "One","Two","Three","Four","Five","Six");

	}

}
