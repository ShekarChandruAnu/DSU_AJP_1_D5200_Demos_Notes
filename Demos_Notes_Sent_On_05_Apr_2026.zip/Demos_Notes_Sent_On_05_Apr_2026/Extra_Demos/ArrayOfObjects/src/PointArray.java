class Point
{
	int x,y;
	
	public Point()
	{
		x=0;
		y=0;
	}
	public Point(int a,int b)
	{
		x= a;
		y= b;
	}
	public void displayPoint()
	{
		System.out.println("Coordinate x is :"+x+" And y is : "+y);
	}
	
}

public class PointArray {

	public int returnInt()
	{
		int x=100;
		return x;
	}
	public void getData()
	{
		
	}
	public String getStrings()
	{
		return "hello";
	}
	
	public Point[] generatePointArray()
	{
		Point[] points = new Point[10];
		
		for(int i=0;i<10;i++)
		{
			points[i]=new Point(i+1,(i+1)*10);
			//Student s = new Student("harsha",78)
			//s[0] = new Student("harsha",78)
		}
		return points;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PointArray poi = new PointArray();
		/*Point[] px = new Point[10];
		px = poi.generatePointArray(); */
		
		Point[] px = new Point[10];
		px = poi.generatePointArray(); 
		
		for(int i=0;i<10;i++)
		{
			px[i].displayPoint();
		}
		

	}

}
