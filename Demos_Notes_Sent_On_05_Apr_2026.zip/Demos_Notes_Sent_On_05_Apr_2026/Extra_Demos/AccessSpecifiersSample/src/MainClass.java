import com.bt.pack1.*;
import com.bt.pack2.*;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		com.bt.pack1.Class1 objc1 = new com.bt.pack1.Class1();
		objc1.class1Method1();
		
		com.bt.pack2.Class1 objc2 = new com.bt.pack2.Class1();
		objc2.class1Method2();
		
		ClassA objA = new ClassA();
		ClassB objB = new ClassB();
		objB.methodToAccessClassA();
		
		ClassC objC = new ClassC();
		objC.methodToAccessClassAOfPack1();
		DerivedClassA dca = new DerivedClassA();
		dca.accessClassA();
		
		DerivedClassAPack2 dcap2 = new DerivedClassAPack2();
		dcap2.accessClassAFromPack2();
		
		
		ClassA ca = new ClassA();
		ClassB cb = new ClassB();
		//Directly Cannot access avariable outside the class You need object
		// System.out.println("Accessing ClassA variable vara1 "+vara1);
		//System.out.println("Accessing ClassA variable vara2 "+vara2);
		//System.out.println("Accessing ClassA variable vara3 "+vara3);
		//System.out.println("Accessing ClassA variable vara1 "+vara4);
		//Default cannot be accessible outside package
		//System.out.println("Accessing ClassA variable vara1 "+ca.vara1);
		//Private vara2 not accessible
		//System.out.println("Accessing ClassA variable vara2 "+ca.vara2);
		//Protected vara3 not accessible
		//System.out.println("Accessing ClassA variable vara3 "+ca.vara3);
		//public vara3 acccessible
		System.out.println("Accessing ClassA variable vara1 "+ca.vara4);
		
		
		
		
		
		
		
	}

}
