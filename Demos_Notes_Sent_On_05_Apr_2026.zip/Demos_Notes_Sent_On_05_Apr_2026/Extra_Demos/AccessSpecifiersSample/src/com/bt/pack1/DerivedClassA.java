package com.bt.pack1;

public class DerivedClassA extends ClassA{
	
	public void accessClassA()
	{
		//Accessing ClassA 's default variable vara1
		//Please note we did not create object
		System.out.println("accessing vara1 of ClassA :"+vara1);
		//Private Variable not accessible in the derived class also
		//System.out.println("accessing vara2 of ClassA :"+vara2);
		//Protected variable accessible
		System.out.println("accessing vara3 of ClassA :"+vara3);
		//public variable accessible
		System.out.println("accessing vara4 of ClassA :"+vara4);
	}

}
