package com.bt.pack1;

public class Class1 {

	public void class1Method1()
	{
		System.out.println("Displaying Method1 of Class1 Of pack1");
	}
	
}
