package com.bt.pack1;

public class ClassA {

	int vara1=10;
	private int vara2=20;
	protected int vara3=30;
	public int vara4=40;
	
	public void methodA()
	{
		System.out.println("Displaying Class A");
	}
	
}
