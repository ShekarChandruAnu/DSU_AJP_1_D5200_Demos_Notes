package com.bt.pack1;

public class ClassB {

	int varb1;
	private int varb2;
	protected int varb3;
	public int varb4;
	
	ClassA aObj;
	public ClassB()
	{
		aObj = new ClassA();
	}
	public void methodB()
	{
		System.out.println("Displaying Class B");
	}
	public void methodToAccessClassA()
	{
		//Datamembers of any other class cannot be accessed without objects
		//irrespective of the access specifier
		//System.out.println("vara1 of ClassA accessed "+vara1);
		//vara1 is default so accessible
		System.out.println("vara1 of ClassA accessed "+aObj.vara1);
		//Cannot access vara2 since it is private
		//System.out.println("vara2 of ClassA accessed "+aObj.vara2);
		//Protected variables are accessible within any class within same Package
		System.out.println("vara3 of ClassA accessed "+aObj.vara3);
		//public variables are accessible anywhere
		System.out.println("vara4 of ClassA accessed "+aObj.vara4);
		
		
	}
}
