package com.bt.pack2;
import com.bt.pack1.ClassA;
public class ClassC {

	int varc1;
	private int varc2;
	protected int varc3;
	public int varc4;
	ClassA obja;
	
	public ClassC()
	{
		obja = new ClassA();
	}
	
	public void methodC()
	{
		System.out.println("Displaying Class C");
	}
	public void methodToAccessClassAOfPack1()
	{
		//
		//vara1 is default cannot be accessible outside the package
		//System.out.println("Accessing default vara1 of ClassA of Pack1 : "+obja.vara1);
		//vara2 is private cannot be accessible outside classA
		//System.out.println("Accessing private vara1 of ClassA of Pack1 : "+obja.vara2);
		//vara3 is protected , can be accessible only by the derived class
		//System.out.println("Accessing protected vara1 of ClassA of Pack1 : "+obja.vara3);
		//accessing vara4 is possible since it is public
		System.out.println("Accessing public vara1 of ClassA of Pack1 : "+obja.vara4);
		
	}
}
