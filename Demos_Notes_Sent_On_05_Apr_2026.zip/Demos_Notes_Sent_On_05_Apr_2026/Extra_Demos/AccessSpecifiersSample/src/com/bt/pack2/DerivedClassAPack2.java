package com.bt.pack2;

import com.bt.pack1.ClassA;

public class DerivedClassAPack2 extends ClassA{

	ClassA obja ;
	public DerivedClassAPack2()
	{
		obja = new ClassA();
	}
	public void accessClassAFromPack2()
	{
		//DERIVED CLASS DOES NOT USE OBJECT
		//CANNOT ACCESS vara1 which is default we are outside package
		//System.out.println("accessing vara1 "+obja.vara1);
		//CANNOT ACCESS PRIVATE DATAMEMBER VARA2
		//private not accesible
		//System.out.println("accessing vara2 "+vara2);
		//System.out.println("accessing vara2 "+obja.vara2);
		//vara3 is protected
		System.out.println("accessing vara3 "+vara3);
		//accessing vara4 which is public
		System.out.println("accessing vara4 "+vara4);
	}
}
