package com.bt.pack2;

public class Class1 {

	
	public void class1Method2()
	{
		System.out.println("Displaying Method2 of Class1 Of pack2");
	}
	
}
