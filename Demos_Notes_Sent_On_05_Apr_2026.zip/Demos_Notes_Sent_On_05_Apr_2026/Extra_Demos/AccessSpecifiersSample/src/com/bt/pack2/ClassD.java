package com.bt.pack2;

public class ClassD {

	int vard1;
	private int vard2;
	protected int vard3;
	public int vard4;
	
	public void methodD()
	{
		System.out.println("Displaying Class D");
	}
}
