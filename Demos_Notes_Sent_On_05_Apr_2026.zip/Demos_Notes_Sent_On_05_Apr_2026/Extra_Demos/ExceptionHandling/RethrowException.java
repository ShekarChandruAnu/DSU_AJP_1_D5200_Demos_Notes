class RethrowException
{
	static void throwDemo()
	{
		try
		{
			throw new NullPointerException("MyException");
		}
		catch(NullPointerException e)
		{
		System.out.println("Exception caught in throwdemo() method");
		throw e;
		}
	}
	public static void main(String args[])
	{
	try
	{
	throwDemo();
	}
	catch(NullPointerException e)
	{
	System.out.println("Exception caught :"+e);
	}
	}
}
	