class userexception extends Exception
{
int num1,num2,sum;
userexception(int a,int b)
{
num1=a;
num2=b; 
sum=a+b;
}
	public String toString()
	{
	return "UserException Caught : The sum of the numbers  Exceeds 20...";
	}
}
	class userexceptiondemo
	{
	static void calculate(int a,int b) throws userexception
	{	
	int sum;
	System.out.println("Calculate(int a,int b) throws UserException");
	System.out.println("Calculate Method("+a+","+b+")");
	sum=a+b;
	if(sum>20)
	throw new userexception(a,b);
	System.out.println("The value of the sum of 2 numbers is :"+sum);
	}
public static void main(String arg[])
{
try
{
calculate(12,1);
calculate(15,7);
}
catch (userexception obja)
{
System.out.println("Caught :"+obja);
}
}
}
