class BalanceAssertDemo
{
static float balance=1500;
static float transaction(float amt)
{
balance=balance-amt;
System.out.println("The current balance is :"+balance);
return balance;
}
public static void main(String args[])
{
float n;
for(int i=0;i<4;i++)
{
n=transaction(400);
assert balance >= 500.00:"balance is below 500";
}
}
}