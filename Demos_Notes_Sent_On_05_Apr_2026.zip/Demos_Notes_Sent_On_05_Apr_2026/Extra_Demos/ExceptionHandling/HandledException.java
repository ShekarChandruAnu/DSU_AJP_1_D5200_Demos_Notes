class HandledException
{
	public static void main(String arg[])
	{
	int num1=0,num2=5;
		try
		{
		int num3=num2/num1;
		System.out.println("The num3= "+num3);
		}
		catch(ArithmeticException e)
		{
		System.out.println("Sorry,Division by Zero is performed");
		}
	System.out.println("WE ARE ABOUT TO LEAVE THE MAIN");
	}

}