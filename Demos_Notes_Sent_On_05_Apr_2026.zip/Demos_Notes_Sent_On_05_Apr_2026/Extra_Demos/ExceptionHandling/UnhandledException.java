class UnhandledException
{
	public static void main(String arg[])
	{
	int num1=0,num2=5;
	int num3=num2/num1;
	System.out.println("The num3= "+num3);
	System.out.println("We Are About To Leave main");
	}
	
}
