
public class MainClass {

	public void callParser(Parser p)
	{
		p.parseDocument();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parser pa;
		pa = new JSONParser();
		MainClass mc = new MainClass();
		mc.callParser(pa);
		//-------------------------------------
		
		pa = new XMLParser();
		mc.callParser(pa);
		//Class1 ca = new Class1();
		

	}

}
