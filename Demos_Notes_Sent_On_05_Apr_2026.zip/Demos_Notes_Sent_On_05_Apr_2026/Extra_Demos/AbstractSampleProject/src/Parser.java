
public abstract class Parser 
{
	 
	public abstract void parseDocument();
	
	public void myMethodWithDefn()
	{
		System.out.println("Implemented Method Being Called");
	}

}
