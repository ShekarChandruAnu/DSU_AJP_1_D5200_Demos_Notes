
public class JSONParser extends Parser {

	@Override
	public void parseDocument() {
		// TODO Auto-generated method stub
		System.out.println("We Have Parsed an JSON Document...");
	}



}
