
public class XMLParser extends Parser
{
	@Override
	public void parseDocument()
	{
		System.out.println("We Have Parsed an XML Document......");
	}
	
}
