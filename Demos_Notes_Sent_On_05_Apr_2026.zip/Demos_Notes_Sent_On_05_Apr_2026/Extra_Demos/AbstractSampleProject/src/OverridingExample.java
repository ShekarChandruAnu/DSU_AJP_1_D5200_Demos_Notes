class BaseClass
{
	//public void disp1()
	public void disp()
	{
		System.out.println("Displaying Base Class disp1.....");
	}
	
}
class DerivedClass1 extends BaseClass
{
	//public void disp2()
	public void disp()
	{
		System.out.println("Displaying Derived Class disp2....");
	}
}
class DerivedClass2 extends BaseClass
{
	
}
public class OverridingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedClass1 dc1 = new DerivedClass1();
		dc1.disp();
		dc1.disp();

	}

}
