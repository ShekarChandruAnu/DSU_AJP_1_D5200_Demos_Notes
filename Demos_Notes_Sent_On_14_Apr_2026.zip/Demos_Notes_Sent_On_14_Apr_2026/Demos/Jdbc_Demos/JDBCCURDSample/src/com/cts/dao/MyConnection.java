package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

	Connection con;
	//   192.65.76.87 - localhost:8080/login
	// http://www.flipkart.com/page1
	String url="jdbc:mysql://localhost:3306/ctsdata1";
	String user = "root";
	String password = "MySQL_@123456";
	// java.lang  [Object / System/Class]---->Class
	public Connection getMyConnection()
	{
		try {
			//LOADING THE DRIVER
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Establishing the Connection
			con = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		//Returning the Connection that is established
		return con;
	}
}
