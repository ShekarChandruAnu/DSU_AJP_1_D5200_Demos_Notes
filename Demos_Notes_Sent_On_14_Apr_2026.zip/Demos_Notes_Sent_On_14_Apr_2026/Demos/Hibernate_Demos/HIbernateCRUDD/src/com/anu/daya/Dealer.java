package com.anu.daya;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Dealer")
public class Dealer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="dealerName")
	String dealerName;
	
	@Column(name="dealerPhone")
	String dealerPhone;

	public Dealer() {
		super();
	}

	public Dealer(int id, String dealerName, String dealerPhone) {
		super();
		this.id = id;
		this.dealerName = dealerName;
		this.dealerPhone = dealerPhone;
	}

	public Dealer(String dealerName, String dealerPhone) {
		super();
		this.dealerName = dealerName;
		this.dealerPhone = dealerPhone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getDealerPhone() {
		return dealerPhone;
	}

	public void setDealerPhone(String dealerPhone) {
		this.dealerPhone = dealerPhone;
	}

	@Override
	public String toString() {
		return "Dealer [id=" + id + ", dealerName=" + dealerName + ", dealerPhone=" + dealerPhone + "]";
	}
	
	
	

}
