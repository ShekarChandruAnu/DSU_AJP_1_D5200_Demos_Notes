package com.anu.daya;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SampleInsert {

	public void insertRecord(Student student)
	{
		SessionFactory sFactory = new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Student.class)
									.buildSessionFactory();
		Session mySession = sFactory.openSession();
		try
		{
			mySession.beginTransaction();
			mySession.save(student);
			mySession.getTransaction().commit();
		}
		finally
		{
			mySession.close();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = new Student("Harsha","har@gmail.com","MCA");
		SampleInsert sInsert = new SampleInsert();
		sInsert.insertRecord(student);
		System.out.println("Inserted Record Successfully...");
	}

}
