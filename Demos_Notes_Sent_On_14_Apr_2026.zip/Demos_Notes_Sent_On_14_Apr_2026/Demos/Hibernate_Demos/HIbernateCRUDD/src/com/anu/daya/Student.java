package com.anu.daya;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="studName")
	String studName;
	
	@Column(name="studMailId")
	String studMailId;
	
	@Column(name="studCourse")
	String studCourse;

	public Student() {
		super();
	}

	public Student(int id, String studName, String studMailId, String studCourse) {
		super();
		this.id = id;
		this.studName = studName;
		this.studMailId = studMailId;
		this.studCourse = studCourse;
	}

	public Student(String studName, String studMailId, String studCourse) {
		super();
		this.studName = studName;
		this.studMailId = studMailId;
		this.studCourse = studCourse;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getStudMailId() {
		return studMailId;
	}

	public void setStudMailId(String studMailId) {
		this.studMailId = studMailId;
	}

	public String getStudCourse() {
		return studCourse;
	}

	public void setStudCourse(String studCourse) {
		this.studCourse = studCourse;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", studName=" + studName + ", studMailId=" + studMailId + ", studCourse="
				+ studCourse + "]";
	}
	
	
}
