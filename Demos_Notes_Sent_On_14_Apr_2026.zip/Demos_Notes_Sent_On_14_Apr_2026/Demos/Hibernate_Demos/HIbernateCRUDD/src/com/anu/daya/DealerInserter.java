package com.anu.daya;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DealerInserter {

	public void insertDealer(Dealer dealer)
	{
		SessionFactory sFactory = new Configuration()
										.configure("hibernate.cfg.xml")
										.addAnnotatedClass(Dealer.class)
										.buildSessionFactory();
		Session session = sFactory.openSession();
		try
		{
			session.beginTransaction();
			session.save(dealer);
			session.getTransaction().commit();
		}
		finally
		{
			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DealerInserter dInserter = new DealerInserter();
		Dealer dealer1 = new Dealer("KR Dealers","8949949949");
		dInserter.insertDealer(dealer1);
		System.out.println("inserted successfully");

	}

}
