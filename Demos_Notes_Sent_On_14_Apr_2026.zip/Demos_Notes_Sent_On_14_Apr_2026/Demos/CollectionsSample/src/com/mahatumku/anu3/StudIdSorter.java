package com.mahatumku.anu3;

import java.util.Comparator;

public class StudIdSorter implements Comparator <Student>{

	@Override
	public int compare(Student student1, Student student2) {
		// TODO Auto-generated method stub
		if(student1.getStudId().compareTo(student2.getStudId()) > 0)
		{
			return 1;
		}
		else if (student1.getStudId().compareTo(student2.getStudId()) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
			
	}

}
