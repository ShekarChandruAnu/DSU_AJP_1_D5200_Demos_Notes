select * from employees order by employeeSalary desc;

select * from employees order by employeeSalary desc limit 2;


select * from employees where employeeSalary <
(select max(employeeSalary) from employees)
order by employeeSalary desc limit 1;

create table empSalary as
select * from employees where employeeSalary <
(select max(employeeSalary) from employees);
select * from empSalary order by employeeSalary desc;