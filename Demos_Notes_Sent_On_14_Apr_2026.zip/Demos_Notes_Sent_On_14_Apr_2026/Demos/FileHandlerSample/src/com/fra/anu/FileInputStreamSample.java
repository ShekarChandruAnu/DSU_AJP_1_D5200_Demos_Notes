package com.fra.anu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamSample {

	FileInputStream fis;
	byte[] myBytes = new byte[100];
	public  void readFromBinaryStream()
	{
		try {
			fis = new FileInputStream("customer.txt");
			fis.read(myBytes);
			String strBytes = new String(myBytes);
			fis.close();
			System.out.println("The Data That was Read from file is "+strBytes);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStreamSample fits = new FileInputStreamSample();
		fits.readFromBinaryStream();

	}

}
