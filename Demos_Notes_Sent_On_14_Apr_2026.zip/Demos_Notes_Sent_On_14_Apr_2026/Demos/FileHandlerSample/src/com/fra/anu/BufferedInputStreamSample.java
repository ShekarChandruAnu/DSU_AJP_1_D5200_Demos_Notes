package com.fra.anu;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedInputStreamSample {

	BufferedInputStream bis;
	byte[] mybytes = new byte[100];
	public void readFromBufferedOutputStream()
	{
		try {
			bis = new BufferedInputStream(new FileInputStream("dealer.txt"));
			bis.read(mybytes);
			String str = new String(mybytes);
			bis.close();
			System.out.println("The Data read from Binary STream thru Buffer is :"+str);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedInputStreamSample biStream = new BufferedInputStreamSample();
		biStream.readFromBufferedOutputStream();
	}

}
