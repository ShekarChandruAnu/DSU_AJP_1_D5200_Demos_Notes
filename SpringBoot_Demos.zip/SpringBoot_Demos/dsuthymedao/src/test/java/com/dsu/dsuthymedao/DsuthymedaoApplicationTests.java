package com.dsu.dsuthymedao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsuthymedaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
