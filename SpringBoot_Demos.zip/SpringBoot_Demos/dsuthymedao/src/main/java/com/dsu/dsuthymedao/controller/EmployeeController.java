package com.dsu.dsuthymedao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dsu.dsuthymedao.model.Employee;
import com.dsu.dsuthymedao.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeService empService;
	
	@GetMapping("/getAll")
	public String getAllEmployees(Model model)
	{
		List <Employee> employees = empService.getAllEmployees();
		model.addAttribute("myEmployees", employees);
		return "employeeList";
	}
	
	@GetMapping("/addNewEmployee")
	public String showAddEmployeeForm(Model model)
	{
		Employee employee = new Employee();// HERE MODEL IS EMBEDDED WITH EMPTY BEAN - EMPLOYEE OBJECT
		model.addAttribute("employee", employee);
		return "employeeForm";
	}
	
	@PostMapping("/saveEmployee")
	public String saveEmployees(@ModelAttribute Employee employee)
	{
		empService.saveEmployee(employee);
		return "redirect:/employees/getAll";
	}
	
	@PostMapping("/showFormForUpdate")
	public String showUpdateForm(Model model,@RequestParam("empId") int empId)
	{
		// HERE MODEL IS EMBEDDED WITH EMPLOYEE RECORD - for that ID which is to be UPDATED
		Employee employeeU = empService.getEmployeeById(empId);
		model.addAttribute("employee", employeeU);
		return "employeeForm";
	}

	@PostMapping("/deleteById")
	public String deleteEmployeeById(@RequestParam("empId") int empId)
	{
		empService.deleteEmployeeById(empId);
		return "redirect:/employees/getAll";
	}
}
