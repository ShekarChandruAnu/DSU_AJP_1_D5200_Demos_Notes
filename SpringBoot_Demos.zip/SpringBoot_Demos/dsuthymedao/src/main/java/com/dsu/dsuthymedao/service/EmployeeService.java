package com.dsu.dsuthymedao.service;

import java.util.List;

import com.dsu.dsuthymedao.model.Employee;

public interface EmployeeService {
	
	public List <Employee> getAllEmployees();
	public Employee getEmployeeById(int empId);
	public void saveEmployee(Employee employee);
	public void deleteEmployeeById(int empId);

}
