package com.dsu.dsuthymedao.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsu.dsuthymedao.model.Employee;
import com.dsu.dsuthymedao.repo.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepository empRepo;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empRepo.findAll(); // EQUIVALENT to session.createQuery("from Employee").list()
	}

	@Override
	public Employee getEmployeeById(int empId){
		// TODO Auto-generated method stub
		Optional <Employee> emplo =  empRepo.findById(empId);
		if(emplo.isPresent())
		{
			return emplo.get();
		}
		else
		{
			return null;
		}
	}

	@Override
	public void saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		empRepo.save(employee);
		
	}

	@Override
	public void deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		empRepo.deleteById(empId);
		
	}

}
