package com.dsu.dsuthymedao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsuthymedaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsuthymedaoApplication.class, args);
	}

}
