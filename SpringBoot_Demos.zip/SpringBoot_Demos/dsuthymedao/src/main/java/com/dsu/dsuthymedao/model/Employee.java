package com.dsu.dsuthymedao.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data // LOMBOK GENERATES GETTERS/SETTERS CONSTRUCTORS/OVERLOADED CONSTRUCTORS
@Table(name="employees")
public class Employee {

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="emp_Id")
		int empId;
		
		@Column(name="first_Name")
		String firstName;
		
		@Column(name="last_Name")
		String lastName;
		
		@Column(name="designation")
		String designation;
		
		@Column(name="department")
		String department;
}
