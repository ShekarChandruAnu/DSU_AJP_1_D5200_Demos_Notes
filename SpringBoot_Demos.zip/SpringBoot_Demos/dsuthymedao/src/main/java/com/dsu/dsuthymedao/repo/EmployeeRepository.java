package com.dsu.dsuthymedao.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dsu.dsuthymedao.model.Employee;

public interface EmployeeRepository extends JpaRepository <Employee,Integer>{

}
