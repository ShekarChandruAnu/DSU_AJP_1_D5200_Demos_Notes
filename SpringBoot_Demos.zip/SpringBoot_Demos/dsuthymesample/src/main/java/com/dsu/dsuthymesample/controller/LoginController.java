package com.dsu.dsuthymesample.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dsu.dsuthymesample.model.Login;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@GetMapping("/showLoginPage")
	public String showLoginForm(Model model)
	{
		Login login = new Login();
		model.addAttribute("login", login);
		return "loginPage";
	}
	
	@GetMapping("/authenticate")
	public String authenticateUser(@ModelAttribute Login login,Model model)
	{
		model.addAttribute("login", login);
		if(login.getLoginId().equals("Admin") && login.getPassword().equals("password"))
		{
			return "success";
		}
		else
		{
			return "failedPage";
		}
	}

}
