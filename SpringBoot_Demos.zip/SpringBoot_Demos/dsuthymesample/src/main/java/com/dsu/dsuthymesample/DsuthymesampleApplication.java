package com.dsu.dsuthymesample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsuthymesampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsuthymesampleApplication.class, args);
		System.out.println("Hello Welcome to SpringBoot");
	}

}
