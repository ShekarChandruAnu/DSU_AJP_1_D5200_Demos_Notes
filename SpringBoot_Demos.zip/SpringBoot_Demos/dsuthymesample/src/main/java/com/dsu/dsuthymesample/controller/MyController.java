package com.dsu.dsuthymesample.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class MyController {
	
	@GetMapping("/sayHi")
	public String sayHello(Model model)
	{
		String message = "Welcome to Thymeleaf based SPRINGBoot apps..";
		model.addAttribute("message", message);
		return "welcome";
	}

}
