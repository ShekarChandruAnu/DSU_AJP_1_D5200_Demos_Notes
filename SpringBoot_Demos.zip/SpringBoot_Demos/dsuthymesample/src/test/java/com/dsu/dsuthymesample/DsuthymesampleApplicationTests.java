package com.dsu.dsuthymesample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsuthymesampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
