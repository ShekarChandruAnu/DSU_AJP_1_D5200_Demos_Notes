package com.dsu.dsuSampleWeb.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dsu.dsuSampleWeb.model.Employee;
import com.dsu.dsuSampleWeb.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeService empSvc;
	
	@GetMapping("/getAll")
	public String getAllEmployees(Model model)
	{
		ArrayList <Employee> employees = empSvc.getAllEmployeesSvc();
		model.addAttribute("myEmployees", employees);
		return "employeeList";
	}
	
	

}
