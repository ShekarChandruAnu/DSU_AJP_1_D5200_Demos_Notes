package com.dsu.dsuSampleWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsuSampleWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsuSampleWebApplication.class, args);
		System.out.println("Welcome to SPRINGBoot Apps..");
	}

}
