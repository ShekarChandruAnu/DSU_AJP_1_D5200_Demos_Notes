package com.dsu.dsuSampleWeb.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.dsu.dsuSampleWeb.model.Employee;

@Repository
public class EmployeeRepository {
	
	ArrayList <Employee> employees;
	
	public EmployeeRepository()
	{
		employees = new ArrayList<Employee>();
	}
	
	public ArrayList <Employee> getAllEmployees()
	{
		employees.add(new Employee("E001","Rakesh ","Gupta","Software Engineer","Design"));
		employees.add(new Employee("E002","Rajesh ","Mehta","Test Engineer","Testing"));
		employees.add(new Employee("E003","Rajendra ","Mehra","Architect","Design"));
		employees.add(new Employee("E004","Mahendra ","Naik","Support Representative","Support"));
		employees.add(new Employee("E005","Sumesh ","Naik","Software Engineer","Design"));
		employees.add(new Employee("E006","Kiran Kumar ","Chodhary","Software Engineer","Design"));
		return employees;
	}

}
