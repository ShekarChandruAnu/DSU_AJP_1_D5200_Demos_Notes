package com.dsu.dsuSampleWeb.service;

import org.springframework.stereotype.Service;

import com.dsu.dsuSampleWeb.model.Login;

@Service
public class LoginService {
	
	
	public boolean authenticateUser(Login login)
	{
		if(login.getLoginId().equals("Admin") && login.getPassword().equals("password"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
