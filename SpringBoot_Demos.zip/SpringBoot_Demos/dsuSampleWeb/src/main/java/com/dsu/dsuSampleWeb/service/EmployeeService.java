package com.dsu.dsuSampleWeb.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsu.dsuSampleWeb.dao.EmployeeRepository;
import com.dsu.dsuSampleWeb.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository empRepo;
	
	public ArrayList <Employee> getAllEmployeesSvc()
	{
		return empRepo.getAllEmployees();
	}

}
