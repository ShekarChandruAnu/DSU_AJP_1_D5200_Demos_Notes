package com.dsu.dsuSampleWeb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dsu.dsuSampleWeb.model.Login;
import com.dsu.dsuSampleWeb.service.LoginService;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	LoginService loginSvc;
	
	
	//LoginService lService = new LoginService();
	@GetMapping("/showLoginPage")
	public String goToLoginPage(Model model)
	{
		Login login = new Login();
		login.setLoginId("");
		login.setPassword("");
		model.addAttribute("login", login);
		
		return "loginPage";
	}
	
	@GetMapping("/authenticate")
	public String authenticateLogin(@ModelAttribute Login login)
	{
		if(loginSvc.authenticateUser(login))
		{
			return "success";
		}
		else
		{
			return "failedLogin";
		}
	}

}
