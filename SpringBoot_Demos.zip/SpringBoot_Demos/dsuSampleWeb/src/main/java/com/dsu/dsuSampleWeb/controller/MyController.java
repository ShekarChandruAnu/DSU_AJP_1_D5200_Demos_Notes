package com.dsu.dsuSampleWeb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
// ctrl+shift+O   (o for othello)
@Controller
@RequestMapping("/hello")
public class MyController {
	
	@GetMapping("/sayHi")
	public String sayHello()
	{
		return "welcome";
	}
	

}
