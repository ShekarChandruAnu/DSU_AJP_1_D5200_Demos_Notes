<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="aqua">
	<center>
		<h2>Welcome to SPRING MVC Apps!!!</h2>
		<a href="/login/showLoginPage">Click Here to Go To Login Page!!!</a>
	</center>

</body>
</html>