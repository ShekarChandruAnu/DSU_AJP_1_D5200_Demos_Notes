<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
   <%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %> 
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="aqua">
<center>

<form:form method="Get" action="authenticate" modelAttribute="login">
<table border="2">
<h2>Welcome to Login Page</h2>
<tr>
	<td colspan="2">Login Page </td>
</tr>
<tr>
	<td>Login Id :</td>
	<td><form:input name="loginId" path="loginId"/></td>
</tr>
<tr>
	<td>Password :</td>
	<td><form:password name="password" path="password"/></td>
</tr>
<tr>
	<td><input type="submit" value="Login..." /></td>
	<td><input type="reset" value="Reset.." /></td>
</tr>

</table>
</form:form>

</center>
</body>
</html>