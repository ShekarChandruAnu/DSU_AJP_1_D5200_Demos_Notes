<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<center>
<h2> Successful Login!!!</h2>
<h3>Welcome to Employees Details Page!!!</h3>
<h3>To View Employees Click the Link Below!!!</h3>
<a href="/employees/getAll">See Employees</a>
</center>


</body>
</html>