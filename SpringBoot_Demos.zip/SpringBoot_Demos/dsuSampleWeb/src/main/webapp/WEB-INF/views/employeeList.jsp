<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<center>
<h2>Welcome To Employees Data Manipulation Page!!!</h2>
<table border="2">
<tr>
	<th>Employee Id</th>
	<th>Employee First Name</th>
	<th>Employee LastName</th>
	<th>Employee Designation</th>
	<th>Employee Department</th>
</tr>
<c:forEach items="${myEmployees}" var="employee">
<tr>
	<td>${employee.empId}</td>
	<td>${employee.firstName}</td>
	<td>${employee.lastName}</td>
	<td>${employee.designation}</td>
	<td>${employee.department}</td>
</tr>
</c:forEach>

</table>

</center>
</body>
</html>