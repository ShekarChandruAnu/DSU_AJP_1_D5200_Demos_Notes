package com.dsu.dsuSampleWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsuSampleWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
