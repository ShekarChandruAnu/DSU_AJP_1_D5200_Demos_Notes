package com.dsu.sampledsu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampledsuApplicationTests {

	@Test
	void contextLoads() {
	}

}
