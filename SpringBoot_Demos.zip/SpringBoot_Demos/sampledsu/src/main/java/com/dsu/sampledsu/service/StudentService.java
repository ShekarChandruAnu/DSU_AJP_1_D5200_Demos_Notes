package com.dsu.sampledsu.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dsu.sampledsu.model.Student;
import com.dsu.sampledsu.reposi.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	StudentRepository studRepo;
	
	public ArrayList <Student> getStudentsList()
	{
		return studRepo.getAllStudents();
	}

}
