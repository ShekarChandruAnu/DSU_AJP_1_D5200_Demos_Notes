package com.dsu.sampledsu.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
	
	String studId;
	String studName;
	String studAddress;
	int avgScore;
	
	

}
