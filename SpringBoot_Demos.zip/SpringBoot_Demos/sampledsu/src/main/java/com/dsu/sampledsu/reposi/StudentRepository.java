package com.dsu.sampledsu.reposi;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.dsu.sampledsu.model.Student;

@Repository
public class StudentRepository {
	
	ArrayList <Student> students;
	public StudentRepository()
	{
		students = new ArrayList<Student>();
	}
	
	public ArrayList <Student> getAllStudents()
	{
		students.add(new Student("S001","Harsha","RTNagar",87));
		students.add(new Student("S002","SreeHarsha","Koramangala",77));
		students.add(new Student("S003","Rajesh Kumar","Vijayanagar",76));
		students.add(new Student("S004","Varsha","Jayanagar",78));
		students.add(new Student("S005","Rathan Kumar","Malleswaram",67));
		return students;
	}

}
