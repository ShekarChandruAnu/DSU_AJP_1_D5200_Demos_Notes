package com.dsu.sampledsu.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dsu.sampledsu.model.Student;
import com.dsu.sampledsu.service.StudentService;

@Controller
@RequestMapping("/hello")
public class MyController {
	
	@Autowired
	StudentService studSvc;
	
	@RequestMapping("/sayHi")
	public String sayHello(Model model)
	{
		String mymessage = "We have started SpringBoot..";
		model.addAttribute("message", mymessage);
		return "welcome";
	}
	
	@RequestMapping("/students")
	public String getStudents(Model model)
	{
		ArrayList <Student> students = studSvc.getStudentsList();
		model.addAttribute("students", students);
		return "studentList";
	}

}
