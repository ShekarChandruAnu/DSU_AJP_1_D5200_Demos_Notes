package com.dsu.sampledsu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampledsuApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampledsuApplication.class, args);
		System.out.println("Welcome to SPRINGBoot apps");
	}

}
