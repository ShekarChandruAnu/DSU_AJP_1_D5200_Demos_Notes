<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<center>
<h2>Welcome to Students PAGE!!!</h2>
<table border="2">
<tr>
<th>StudentID</th>
<th>Student Name</th>
<th>Student Address</th>
<th>Average Score</th>
</tr>
<c:forEach items="${students}" var="student">
<tr>
	<td>${student.studId}</td>
	<td>${student.studName}</td>
	<td>${student.studAddress}</td>
	<td>${student.avgScore}</td>

</tr>
</c:forEach>
</table>


</center>

</body>
</html>