<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
	<h2>Welcome to SpringBoot Apps</h2>
	<h2>${message}</h2>
	<a href="/hello/students">Click Here to View Students</a>
</body>
</html>