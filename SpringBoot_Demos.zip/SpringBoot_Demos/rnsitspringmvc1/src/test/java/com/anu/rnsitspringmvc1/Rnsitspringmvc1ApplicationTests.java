package com.anu.rnsitspringmvc1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rnsitspringmvc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
