<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
 <%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="aqua">
<center>
<!-- <form method="Get" action="authenticate" modelAttribute="login">-->
<form:form method="Get" action="authenticate" modelAttribute="login"> 
	<h2>Welcome to Login Page!!!</h2>
	<table border="2">
	<tr>
		<td colspan="2">Login Details</td>
	</tr>
<tr>
	<td>Enter Login ID:</td>
	<td><form:input path="loginId"/></td>
</tr>
<tr>
	<td>Enter Password</td>
	<td><form:password path="password"/></td>
</tr>
<tr>
	<td><input type="submit" value="Login..." /></td>
	<td><input type="reset" value="ReSet..." /></td>
</tr>
</table>
</form:form>
</center>
</body>
</html>