<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<center>
<h2>Successful Login</h2>
<h3>Welcome ${login.loginId} to Employees Data Manipulation Page!!!</h3>
<a href="/employees/getEmployees">Click Here to View Employee Details...</a>
</center>
</body>
</html>