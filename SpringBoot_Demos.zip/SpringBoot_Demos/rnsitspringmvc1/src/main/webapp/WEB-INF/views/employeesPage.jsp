<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<center>
<h2>Welcome to Employees Data Manipulation Page</h2>
<table border="2">
<tr>
	<th>Employee Id</th>
	<th>Employee Name</th>
	<th>Employee Address</th>		
	<th>Employee Phone</th>
	<th>Employee eMail</th>
</tr>
<c:forEach items="${employees}" var="employee">
<tr>
	<td>${employee.empId}</td>
	<td>${employee.empName}</td>
	<td>${employee.empAddress}</td>
	<td>${employee.empPhone}</td>
	<td>${employee.empMail}</td>	
</tr>
</c:forEach>


</table>
</center>

</body>
</html>