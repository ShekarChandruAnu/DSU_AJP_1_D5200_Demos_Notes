<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<center>
<h2>Welcome to SPRINGBoot Based MVC Apps...</h2>
<h3>${message}</h3>
<a href="/login/showLoginPage">Go To Login Page!!!</a>
</center>
</body>
</html>