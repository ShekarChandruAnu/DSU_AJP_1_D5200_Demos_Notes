package com.anu.rnsitspringmvc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.*")
public class Rnsitspringmvc1Application {

	public static void main(String[] args) {
		SpringApplication.run(Rnsitspringmvc1Application.class, args);
		System.out.println("Welcome to SPRINGBoot based MVC apps...");
	}

}
