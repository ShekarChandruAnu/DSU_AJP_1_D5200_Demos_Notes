package com.anu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anu.model.Employee;
import com.anu.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository empRepo;
	
	public List<Employee> getAllEmployeesSvc()
	{
		return empRepo.getAllEmployees();
	}

}
