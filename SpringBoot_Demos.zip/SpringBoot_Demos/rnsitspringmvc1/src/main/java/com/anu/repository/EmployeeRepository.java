package com.anu.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anu.model.Employee;

@Repository
public class EmployeeRepository {
	
	List <Employee> employees;
	
	public EmployeeRepository()
	{
		employees = new ArrayList<Employee>();
	}
	
	public List <Employee> getAllEmployees()
	{
		employees.add(new Employee("E001","Harsha","RTNagar","9849499499","harsha@gmail.com"));
		employees.add(new Employee("E002","SreeHarsha","Koramangala","9849456499","sreeharsha@gmail.com"));
		employees.add(new Employee("E003","Kiran Kumar","Vijayanagar","9843219499","kiran@gmail.com"));
		employees.add(new Employee("E004","Rajendra ","JayaNagar","9846789499","rajen@gmail.com"));
		employees.add(new Employee("E005","Sumanth","IndiraNagar","9849497899","sumant@gmail.com"));
		
		return employees;
	}

}
