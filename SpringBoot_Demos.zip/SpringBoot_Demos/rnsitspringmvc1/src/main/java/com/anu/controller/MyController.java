package com.anu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/greet")
public class MyController {
	
	@RequestMapping("/sayHi")
	public String sayHello(Model model)
	{
		String myMessage = "We are learning SPRINGBoot based MVC App Development";
		model.addAttribute("message", myMessage);
		return "welcome";
	}

}
