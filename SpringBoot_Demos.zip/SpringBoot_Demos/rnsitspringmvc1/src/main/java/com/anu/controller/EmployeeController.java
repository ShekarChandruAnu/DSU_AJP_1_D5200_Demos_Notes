package com.anu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.anu.model.Employee;
import com.anu.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeService empService;
	
	@RequestMapping("/getEmployees")
	public String displayEmployees(Model model)
	{
		List <Employee> myEmployees = empService.getAllEmployeesSvc();
		model.addAttribute("employees", myEmployees);
		return "employeesPage";
	}

}
