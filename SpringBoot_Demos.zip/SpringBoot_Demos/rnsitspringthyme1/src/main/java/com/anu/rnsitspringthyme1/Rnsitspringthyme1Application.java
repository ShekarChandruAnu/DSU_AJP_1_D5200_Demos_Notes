package com.anu.rnsitspringthyme1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rnsitspringthyme1Application {

	public static void main(String[] args) {
		SpringApplication.run(Rnsitspringthyme1Application.class, args);
		System.out.println("Welcome to Thymeleaf based SPRINGBoot Apps... ");
	}

}
