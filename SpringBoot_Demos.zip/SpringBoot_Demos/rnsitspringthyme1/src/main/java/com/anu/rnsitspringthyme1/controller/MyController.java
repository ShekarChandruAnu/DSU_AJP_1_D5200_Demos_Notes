package com.anu.rnsitspringthyme1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/greetings")
public class MyController {
	
	
	@RequestMapping("/sayHello")
	public String greetUser(Model model)
	{
		String message = "We are Learning Thymeleaf based SpringBoot MVC Apps ";
		model.addAttribute("message", message);
		return "welcome";
	}

}
