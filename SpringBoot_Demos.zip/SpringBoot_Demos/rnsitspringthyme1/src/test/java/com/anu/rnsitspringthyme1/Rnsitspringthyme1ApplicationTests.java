package com.anu.rnsitspringthyme1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rnsitspringthyme1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
